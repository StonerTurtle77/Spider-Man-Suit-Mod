  -- Changelog

	- v1.1.1
		- Fixed Base Spider-Mans gloves being white (I think)
                - Added Symbiote Spider-Man

	- v1.1.0
		- Release