  -- Changelog
        - v1.1.3
                - yet again trying to fix white-glove issue
                - hopefully properly added Symbiote Spidey
                - removed x753Suits options from the rack

        - v1.1.2 
                - Attempted to fix white-glove issue
                - Attempted to fix Symbiote Spidey not showing on Suit Rack


	- v1.1.1
		- Fixed Base Spider-Mans gloves being white (I think)
                - Added Symbiote Spider-Man

	- v1.1.0
		- Release